Yellow lines are 'paths', these are hidden by default when loaded with wayfinding.js

Red lines are doors, they are start or end points. These are also hidden by default when loaded with wayfinding.js